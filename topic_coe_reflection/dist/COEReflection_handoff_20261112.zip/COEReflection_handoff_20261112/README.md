# COE 反射衍射程序使用说明

更新日期：2026-11-12。入口：`src/COEReflection_main.m`。

## 1. 在另一台电脑第一次运行

1. 安装 MATLAB；本版本已在 Windows / MATLAB R2024a 验证。核心计算不需要 Simulink 或其它方向的源码；验证使用 MATLAB 自带的 `matlab.unittest`。
2. 完整解压迁移包，保留 `topic_coe_reflection/src/private/`、`Input/Colorimetry/` 及文件层级。不要只复制主脚本，也不要把 `private/` 改名。
3. 在 MATLAB 中打开并运行 `topic_coe_reflection/src/COEReflection_main.m`。路径根据主脚本的位置自动定位，不要求和旧电脑相同的盘符或目录。
4. 迁移包根目录的 `validate_handoff.m` 可运行小规模算法验证；它不依赖 Codex 或 MCP。完整默认仿真产生较大的 MAT 文件，需要保留数百 MB 的磁盘空间及足够内存。
5. 需要 Codex 控制现有 MATLAB 时，另行配置该电脑的 MATLAB MCP，并在当前 MATLAB 会话执行 `shareMATLABSession()`。这不是手动运行程序的前提。

每次运行主脚本会执行 `clearvars`、`clc`、`close all`，清理旧变量和图窗，但保留搜索路径与 MCP 连接。建议从第一节开始完整运行，避免分节执行时混入上一次配置。

## 2. 当前默认配置

| 项目 | 默认值 |
|---|---|
| 入射 | 法向平面波；各波长非相干叠加强度 |
| 光谱 | D65，380–780 nm，5 nm 步长，81 波长 |
| 几何 | 周期 50 μm，圆半径 10 μm，16×16 周期 |
| 采样 | 每周期 32 点，512×512 物面，FFT 补零倍数 4 |
| 输出 | 401×401 角度网格，±6° |
| 材料 | mask=1：n=1.8、k=0.05；mask=0：n=1.5、k=0；均为示例常数 |
| 高度 | **0 nm**，`useHeightExample=false`，暂不叠加额外高度相位 |
| 雾度代理 | 圆锥半角 2.5°，全角 5° |
| 观察角域 | 中心 (0°,0°)，内半角 0°、外半角 2.5° |
| 非零级统计 | 零级排除半角 0.30°，光斑积分半角 0.15°，每组最多 8 个 |
| 色彩图 | 两状态共用曝光与亮度增强；默认局部显示 ±1.5° |

默认高度为零，所以两个状态的物理数组、色彩图、累计曲线和光斑能量应一致。“不叠加高度相位”只把额外高度置零，不清除材料复反射系数自身的相位。

## 3. 主脚本中常改的参数

### 输入与保存

- `inputFile=""`：根据脚本参数生成几何；非空时读取 `Input/` 下的 MAT 文件。
- `caseName`：输出文件名前缀。相同前缀再次运行会覆盖同名结果；对比不同设计时建议使用不同前缀。
- `saveResults=false`：仅计算和显示，不写结果文件。

### 几何、采样和材料

- `cfg.pitch/radius/aspectRatio/cellAnglesDeg` 控制图形；半径、周期单位为 m，旋转角单位为度。
- `cfg.periods=[Nx,Ny]`，两者均需为偶数；矩阵按行 y、列 x 排列。
- `cfg.samplesPerPeriod` 控制物面采样；`paddingFactor` 控制 FFT 补零；`outputSize` 必须为奇数。
- `cfg.materials` 设置两种材料常数 n/k，通过法向单界面 Fresnel 公式生成复振幅反射系数。关闭 `enabled` 后使用 `featureIntensity/backgroundIntensity`，这里的数值是强度反射率，不是振幅。
- `cfg.complexCoefficient` 非空时优先于上述两个材料模型。未来可输入薄膜计算得到的复系数，不必改动 FFT 核心。

### 高度相位

保持 `cfg.heightMap=0`、`useHeightExample=false` 即不添加额外高度。可输入非均匀高度矩阵（m）；反射使用 `4*pi*deltaIndex*heightMap/lambda`。

`useHeightExample=true` 是可选二值条纹演示，高区 687.5 nm、低区 0、周期 12.5 μm、占空比 50%。实际文件输入优先，读取文件时不混入演示高度。均匀高度只改变整体相位，不改变远场强度。若输入复反射系数已含高度相位，应将额外高度设为零。

### 角域与光斑

```matlab
observation.centerDeg = [0, 0];
observation.innerHalfAngleDeg = 0; % 正值可统计环带
observation.halfAngleDeg = 2.5;

spotOptions.zeroOrderExclusionDeg = 0.30;
spotOptions.integrationHalfAngleDeg = 0.15;
spotOptions.minSeparationDeg = 0.35;
spotOptions.maxSpots = 8;
spotOptions.minRelativePeak = 0.08;
spotOptions.wavelengthNm = previewWavelengthNm; % [] 表示统计全部波长
```

所有角度均为**半角或半径**，不是直径。观察角域必须完整位于输出窗口内。光斑积分半角不得小于一个输出角度网格间距。

光斑检测步骤：在两状态原始能量图的逐点最大图上寻找局部峰，排除整个积分圆会进入零级或越界的候选；按候选圆内能量排序，保持圆之间不重叠，保留最多指定数量。然后分别在两个状态的原始能量图中积分同一组圆。定位/排序用的最大图不用于报告物理能量。

同一组内两个状态的 S 编号和积分中心相同；若某一状态的峰移动，表中还会报告该状态在积分圆内的实际峰位置。变化太大时可能选出多个不同位置的圆，能量为零的圆内实际峰位置记为 NaN。

S1、S2 等是**检测亮斑编号**，不是严格的理论 (m,n) 衍射阶数；不同波长/加权组之间的 S 编号也不表示同一理论阶。宽带彩色带状结构只能用选定局部圆域描述，不能把一个圆误解为完整色散带的能量。对称同强峰在不同硬件的微小浮点差异下编号可能互换，应按角坐标匹配。

### 亮度增强与放大

- `toneMapping="log"`：对 Y 做亮度映射，然后等比例缩放 XYZ；`"none"` 关闭增强。
- `toneStrength=3000`、`luminanceGamma=0.75`：提高前者或降低后者可突出暗部。
- `fixedGain=0` 为两状态共同自动曝光，正数固定跨方案曝光；`exposureEV` 对两状态共同补偿。
- `colorView.centerDeg/halfAngleDeg` 只改变 D65 专用图的局部显示范围，不改变仿真或积分。

在 sRGB 色域内，等比例缩放保持 xy；负线性 RGB 的色域裁剪仍可能改变显示色度。原始 XYZ/xy 不修改。不要用增强图的像素值计算能量。

## 4. 自定义 MAT 数据

支持 `mask`、`heightMap`、`complexCoefficient` 中任意字段。二维尺寸必须为 `[Ny,Nx]*samplesPerPeriod`，默认 512×512。系数三维数组的第三维必须与当前波长数和顺序一致，D65 默认是 380:5:780。

| 字段 | 格式及含义 |
|---|---|
| mask | 0–1 材料区域图，推荐二值；不自动缩放或插值 |
| heightMap | 标量或与物面等尺寸的实数高度，单位 m |
| complexCoefficient | 模不大于 1 的复振幅系数；标量、二维或 Ny×Nx×波长数 |

文件中的字段覆盖对应脚本值；其它参数仍由脚本提供。`Input/Colorimetry/` 是随程序分发的官方 CIE 数据，不要删除。

## 5. 图表及统计结果

主程序生成五个图窗：材料/高度图、横向远场对比图、D65 全范围与局部放大图、零级/雾度代理指标图、累计角能量图。远场图按 **2 行×4 列**显示默认三个预览波长和 D65 合成图，上下为两种高度相位状态。若修改预览波长数量，列数自动变化。

图中青线为雾度代理阈值，黄线为观察角域，红点线为零级排除圆，品红圈及 S 编号为非零级积分域。D65 图使用 `photopic` 组光斑标记；单波长图使用对应波长的标记。

默认输出前缀为 `coe_reflection`：

| 文件后缀 | 内容 |
|---|---|
| `_results.mat` | 实际参数、原始光谱能量、XYZ/xy、增强图、所有统计结构 |
| `_diffraction.png` | 横向逐波长 / D65 对比图，含光斑标记 |
| `_d65_color.png` | 大尺寸 D65 全范围与局部图，含光斑标记 |
| `_geometry.png`、`_metrics.png` | 几何及零级/雾度代理指标 |
| `_cumulative_energy.png/.csv` | 累计绝对反射率 |
| `_observation_metrics.csv` | 观察角域绝对反射率和该区域色坐标 |
| `_diffraction_spots.csv` | 非零级光斑中心、实际峰位置、积分半角、绝对反射率 |
| `_metrics.csv`、`_baseline_metrics.csv` | 两状态的逐波长物理指标 |
| `_comparison_metrics.csv` | 两状态的角域、零级及锥外指标对比 |
| `_spectrum.csv` | D65 与三刺激值函数的实际采样数据 |
| `_rgb_without/with_height_phase.png` | 纯增强 RGB 图，无标记 |
| `_srgb_linear_without/with_height_phase.png` | 未增强的线性曝光版 sRGB 图，无标记 |

光斑表中 `Group="wavelength"` 的分母为该波长入射能量；`radiant` 为 D65 波段总入射辐射能；`photopic` 为 D65 入射明视觉光通量（RGB 模式是代理权重）。`AbsoluteReflectancePercent=100*E_ROI/E_incident`，不是光斑在总反射能量中的占比。宽带行 `WavelengthNm=NaN` 是正常的，表示多波长合成。不同组、不同波长、两个状态之间**不能相加**。

## 6. 结果解释和常见问题

- 默认两个状态相同：这是 0 nm 高度的预期行为，不是计算失效。
- 零级降低但光晕增强：纯相位会重新分配能量，不一定降低总反射率；应结合观察角域、累计曲线和非零级能量判断。
- 找不到光斑：检查阈值、零级排除半径和积分半角，确认候选完整位于输出范围；没有候选时会输出只有表头的 CSV。
- CSV 中没有某些弱光斑：受到相对峰阈值、最小间距、最多光斑数及有限窗口筛选。这些选定光斑不代表所有非零级反射能量。
- 窗口能量不足 98%：查看 `CapturedFraction`，扩大角度范围并检查采样；近轴模型限定半范围不超过 10°。显示窗口外能量不会出现在光斑统计中。
- MATLAB 旧版本函数不支持：以已验证的 R2024a 环境为基准，不直接删除输入检查；先核对版本及语法兼容性。
- 中文字体异常：修改 `displayStyle.fontName` 为新电脑已安装的中文字体。
- 修改后结果异常：先关闭高度、保留默认参数运行验证；检查 m/nm、全角/半角、矩阵行列和波长顺序。

雾度值仍是模型锥外能量代理，不等同于 ASTM 标准仪器反射雾度；当前模型也不是全半球矢量散射或真实薄膜堆栈。进一步开发建议见 `项目交接文档.md`。
